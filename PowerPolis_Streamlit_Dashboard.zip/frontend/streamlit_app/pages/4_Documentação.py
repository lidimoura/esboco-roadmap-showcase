import streamlit as st
from utils.i18n import t

def app():
    st.title(t("docs_title"))
    st.markdown(t("docs_intro"))

    st.markdown(f"## {t("essential_links_title")}")
    st.write(f"- [**{t("project_github")}**](https://github.com/No-Country-simulation/G9-BR-TEAM-12)")
    st.write(f"- [**{t("api_contract")}**](https://github.com/No-Country-simulation/G9-BR-TEAM-12/blob/main/docs/contrato-api.md)")
    st.write(f"- [**{t("classification_criteria")}**](https://github.com/No-Country-simulation/G9-BR-TEAM-12/blob/main/docs/criterios-classificacao.md)")
    st.write(f"- [**{t("eda_modeling_notebook")}**](https://colab.research.google.com/github/lidimoura/G9-BR-TEAM-12/blob/main/data-science/notebooks/01_EDA_Exploratoria.ipynb) _({t("notebook_link_note")})_ ")
    st.write(f"- [**{t("presentation_site")}**](https://manus-webdev-energiai-showcase.manus.computer/) _({t("presentation_site_note")})_ ")

    st.markdown(f"## {t("methodology_process_title")}")
    st.write(t("methodology_text"))
    st.write(f"- [**{t("methodology_doc")}**](https://github.com/No-Country-simulation/G9-BR-TEAM-12/blob/main/docs/METODOLOGIA.md) _({t("to_be_created_note")})_ ")
    st.write(f"- [**{t("roadmap_doc")}**](https://github.com/No-Country-simulation/G9-BR-TEAM-12/blob/main/docs/ROADMAP.md) _({t("to_be_created_note")})_ ")

    st.markdown(f"## {t("next_steps_evolution_title")}")
    st.write(t("next_steps_text"))

if __name__ == "__main__":
    app()
